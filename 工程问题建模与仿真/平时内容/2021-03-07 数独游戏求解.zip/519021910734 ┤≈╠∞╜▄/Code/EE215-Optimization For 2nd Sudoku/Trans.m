function B=Trans(x)

[~,~,a]=size(x);
B=zeros(size(x));
for k=1:a
    B(:,:,k)=x(:,:,k)';
end
