function Display(x)

fprintf('The answer is:\n')
for i=1:9
    for j=1:9
         fprintf(num2str(x(i,j)));
         fprintf('\t');
    end
    fprintf('\n');
end
