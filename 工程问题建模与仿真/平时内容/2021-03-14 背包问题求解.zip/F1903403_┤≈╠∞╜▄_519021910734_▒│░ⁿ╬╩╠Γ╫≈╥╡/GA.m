close;
clear;
clc

volume = [7 4 8 11 20 5 3 9 16 7 8 5 4 4 3 12];
weight = [11 7 9 6 7 8 5 6 18 2 3 6 2 9 5 4];
value = [9 8 7 8 18 7 3 10 19 4 4 11 3 5 4 6];

n = length(value);
Pintersect = 0.95;
Pvariation = 0.10; 
Iteration = 2000; 

%初始化种群 
Population = 2000;
max_volume = 95;
max_weight = 86;
gene = zeros(1,n);

rand('state',sum(clock));
zhongqun1 = zeros(Population,n);

for i = 1: Population
    gene = round(rand(1,n));
    while gene* weight' > max_weight || gene * volume' > max_volume
        gene = round(rand(1,n));
    end
    zhongqun1(i,:) = gene;
end

%交叉
for i = 1: Iteration
    zhongqun2 = zhongqun1;
for k = 1: 2 : Population
        if rand < Pintersect 
            pos = ceil(n*rand); 
            temp1 = zhongqun2(k,:);
            temp2 = zhongqun2(k+1,:);
            temp = temp1(pos);
            temp1(pos) = temp2(pos);
            temp2(pos) = temp;
            if temp1 * weight' <= max_weight && temp2 * weight'  <= max_weight && temp1 * volume'  <= max_volume && temp2 * volume'  <= max_volume
                zhongqun2(k,:) = temp1;
                zhongqun2(k+1,:) = temp2;
            end
        end
    end
    
        %变异
        zhongqun3 = zhongqun1; 
        for k = 1: Population
            if rand < Pvariation
                pos = ceil(n*rand);
                temp = zhongqun3(k,:);
                if temp(pos) == 1
                    temp(pos) = 0;
                else
                    temp(pos) = 1;
                end
                if  temp * weight' <= max_weight && temp * volume'  <= max_volume
                    zhongqun3(k,:) = temp;
                end
            end
        end
        
        %选择 
        zhongqun = [zhongqun1;zhongqun2;zhongqun3];
        temp_value = zhongqun*(value'); %适应度计算
        [t index] = sort(temp_value,'descend');
        zhongqun1 = zhongqun(index(1: Population),:);
end

disp('Choice：')
disp(zhongqun(1,:))
disp('Value：')
disp(zhongqun(1,:)*value')
